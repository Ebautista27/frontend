-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 17-09-2024 a las 20:23:59
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `stay_in_style`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito`
--

CREATE TABLE `carrito` (
  `ID_carrito` int(11) NOT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `carrito`
--

INSERT INTO `carrito` (`ID_carrito`, `total`) VALUES
(1, 100.00),
(2, 200.00),
(3, 150.50),
(4, 75.25),
(5, 50.75),
(6, 90.00),
(7, 120.00),
(8, 250.00),
(9, 30.00),
(10, 180.50),
(11, 75.00),
(12, 130.50),
(13, 50.00),
(14, 70.25),
(15, 85.75),
(16, 95.00),
(17, 60.00),
(18, 160.00),
(19, 75.00),
(20, 110.50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito_producto`
--

CREATE TABLE `carrito_producto` (
  `ID_carrito` int(11) NOT NULL,
  `ID_producto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `carrito_producto`
--

INSERT INTO `carrito_producto` (`ID_carrito`, `ID_producto`) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(3, 5),
(4, 6),
(4, 7),
(5, 8),
(6, 9),
(7, 10),
(8, 1),
(8, 5),
(9, 2),
(9, 3),
(10, 4),
(10, 6),
(11, 7),
(11, 8),
(11, 10),
(11, 11),
(12, 9),
(13, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_factura`
--

CREATE TABLE `detalle_factura` (
  `ID_factura` int(11) NOT NULL,
  `ID_producto` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_factura`
--

INSERT INTO `detalle_factura` (`ID_factura`, `ID_producto`, `cantidad`) VALUES
(1, 1, 2),
(1, 2, 1),
(2, 3, 3),
(2, 4, 2),
(3, 5, 1),
(4, 6, 4),
(5, 7, 2),
(6, 8, 3),
(7, 9, 1),
(8, 10, 2),
(9, 1, 1),
(9, 2, 3),
(10, 3, 2),
(10, 4, 1),
(11, 5, 3),
(11, 6, 4),
(12, 7, 2),
(12, 8, 1),
(13, 9, 3),
(13, 10, 2),
(21, 10, 1),
(21, 11, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `ID_factura` int(11) NOT NULL,
  `ID_usuario` int(11) DEFAULT NULL,
  `ID_metodo` int(11) DEFAULT NULL,
  `monto_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`ID_factura`, `ID_usuario`, `ID_metodo`, `monto_total`) VALUES
(1, 10, 1, 100.00),
(2, 11, 2, 200.00),
(3, 12, 3, 150.50),
(4, 13, 1, 75.25),
(5, 14, 2, 50.75),
(6, 10, 3, 90.00),
(7, 11, 1, 120.00),
(8, 12, 2, 250.00),
(9, 13, 3, 30.00),
(10, 14, 1, 180.50),
(11, 15, 2, 75.00),
(12, 16, 1, 95.00),
(13, 17, 3, 85.50),
(14, 18, 2, 150.00),
(15, 19, 4, 175.25),
(16, 20, 2, 120.50),
(17, 15, 3, 110.00),
(18, 16, 1, 100.75),
(19, 17, 2, 130.00),
(20, 18, 3, 80.00),
(21, 15, 2, 75.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `metodo_pago`
--

CREATE TABLE `metodo_pago` (
  `ID_metodo` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `metodo_pago`
--

INSERT INTO `metodo_pago` (`ID_metodo`, `tipo`) VALUES
(1, 'nequi'),
(2, 'daviplata'),
(3, 'paypal'),
(4, 'Bancolombia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `ID_producto` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `talla` varchar(10) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`ID_producto`, `nombre`, `talla`, `categoria`, `estado`, `precio`) VALUES
(1, 'Camiseta', 'M', 'Ropa', 'Disponible', 20.00),
(2, 'Pantalones', 'L', 'Ropa', 'Disponible', 40.00),
(3, 'Zapatos', '42', 'Calzado', 'Disponible', 60.00),
(4, 'Chaqueta', 'L', 'Ropa', 'Disponible', 80.00),
(5, 'Sombrero', 'Único', 'Accesorios', 'Disponible', 15.00),
(6, 'Bufanda', 'Único', 'Accesorios', 'Disponible', 25.00),
(7, 'Guantes', 'M', 'Accesorios', 'Disponible', 10.00),
(8, 'Cinturón', 'Único', 'Accesorios', 'Disponible', 20.00),
(9, 'Sudadera', 'M', 'Ropa', 'Disponible', 35.00),
(10, 'Camisa', 'S', 'Ropa', 'Disponible', 22.00),
(11, 'Jeans', 'M', 'Ropa', 'Disponible', 55.00),
(12, 'Zapatos deportivos', '42', 'Calzado', 'Disponible', 90.00),
(13, 'Chaqueta de cuero', 'L', 'Ropa', 'Disponible', 120.00),
(14, 'Gorra', 'Único', 'Accesorios', 'Disponible', 25.00),
(15, 'Vestido', 'S', 'Ropa', 'Disponible', 70.00),
(16, 'Bufanda de lana', 'Único', 'Accesorios', 'Disponible', 35.00),
(17, 'Camiseta estampada', 'M', 'Ropa', 'Disponible', 30.00),
(18, 'Zapatillas', '40', 'Calzado', 'Disponible', 65.00),
(19, 'Pantalones cortos', 'L', 'Ropa', 'Disponible', 40.00),
(20, 'Sombrero de playa', 'Único', 'Accesorios', 'Disponible', 30.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resena`
--

CREATE TABLE `resena` (
  `ID_resena` int(11) NOT NULL,
  `comentario` text DEFAULT NULL,
  `calificacion` int(11) DEFAULT NULL,
  `ID_producto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `resena`
--

INSERT INTO `resena` (`ID_resena`, `comentario`, `calificacion`, `ID_producto`) VALUES
(1, 'Excelente producto', 5, 1),
(2, 'Muy cómodo', 4, 2),
(3, 'Buena calidad', 5, 3),
(4, 'Perfecto para el invierno', 5, 4),
(5, 'Muy bonito', 4, 5),
(6, 'Ideal para el frío', 5, 6),
(7, 'Muy útil', 3, 7),
(8, 'Buen precio', 4, 8),
(9, 'Recomendado', 5, 9),
(10, 'Súper cómodo', 4, 10),
(11, 'Me encantó el diseño', 5, 11),
(12, 'Muy cómodos', 4, 12),
(13, 'Excelente calidad', 5, 13),
(14, 'Perfecta para el clima frío', 4, 14),
(15, 'Muy elegante', 5, 15),
(16, 'Ideal para invierno', 5, 16),
(17, 'Buen estampado', 4, 17),
(18, 'Cómodas y resistentes', 5, 18),
(19, 'Perfecto para días calurosos', 4, 19),
(20, 'Protección solar óptima', 5, 20),
(21, NULL, 5, 19),
(22, 'Me encanto!', 5, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `ID_rol` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`ID_rol`, `nombre`) VALUES
(1, 'administrador'),
(2, 'usuario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `ID_usuario` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `num_cel` varchar(10) DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `direccion` varchar(30) DEFAULT NULL,
  `password` varchar(20) NOT NULL,
  `ID_rol` int(11) DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`ID_usuario`, `nombre`, `num_cel`, `email`, `direccion`, `password`, `ID_rol`, `estado`) VALUES
(9, 'DilandakRg', '3177201331', 'dilandakrg@gmail.com', 'Calle113a  norte #2a88', 'Dilan1234', 1, 0),
(10, 'Estif Bautista', '3136291107', 'ande27e@gmail.com', 'calle109 sur', '12345678', 1, 1),
(11, 'Juan Perez', '3147798635', 'juan.perez@example.com', 'calle 81 este', '123456', 2, 1),
(12, 'luis vagales', '3145292108', 'carlos@gmail.com', 'carrera 31-86 #45', '12345678', 2, 1),
(13, 'jose antonio nariño', '3146688635', 'jose.antonio@gmail.com', 'calle 13_Av 543', '4536845654765456', 2, 1),
(14, 'Carlos Ulgver', '3177201447', 'carlos.ULG@gmail.com', 'AV 2006 #5b-15', '2312312553345', 2, 1),
(15, 'Ana Torres', '3112233445', 'ana.torres@example.com', 'calle 15 #10-12', '12345678', 2, 1),
(16, 'Ricardo Gómez', '3123344556', 'ricardo.gomez@example.com', 'calle 20 #15-25', 'abcdef12', 2, 1),
(17, 'Laura Mendoza', '3134455667', 'laura.mendoza@example.com', 'calle 30 #20-30', 'qwertyui', 2, 1),
(18, 'Pedro Martínez', '3145566778', 'pedro.martinez@example.com', 'calle 40 #25-35', 'zxcvbnm', 2, 1),
(19, 'Sofía Ruiz', '3156677889', 'sofia.ruiz@example.com', 'calle 50 #30-40', 'password1', 2, 1),
(20, 'Gabriel Garcia Marquez mendez', '5285995555', 'carlos@gmail.com', 'jjj', '$2y$10$E2uvolCkuGjBa', 2, 1),
(21, 'Elena Rojas', '3191122334', 'elena.rojas@example.com', 'calle 60 #35-45', 'clave1234', 2, 1),
(22, 'Manuel Gómez', '3202233445', 'manuel.gomez@example.com', 'calle 70 #40-50', 'pass5678', 2, 1),
(23, 'Lucía Martínez', '3213344556', 'lucia.martinez@example.com', 'calle 80 #45-55', 'abcde123', 2, 1),
(24, 'Fernando Pérez', '3224455667', 'fernando.perez@example.com', 'calle 90 #50-60', 'clave9876', 2, 1),
(25, 'Santiago Ramírez', '3235566778', 'santiago.ramirez@example.com', 'calle 100 #55-65', 'clave4567', 2, 1),
(26, 'Victoria López', '3246677889', 'victoria.lopez@example.com', 'calle 110 #60-70', 'password987', 2, 1),
(27, 'Felipe Torres', '3257788990', 'felipe.torres@example.com', 'calle 120 #65-75', 'pass4567', 2, 1),
(28, 'Natalia Díaz', '3268899001', 'natalia.diaz@example.com', 'calle 130 #70-80', 'password654', 2, 1),
(29, 'Tomás Suárez', '3279900011', 'tomas.suarez@example.com', 'calle 140 #75-85', 'clave3210', 2, 1),
(30, 'Daniela Ruiz', '3281001122', 'daniela.ruiz@example.com', 'calle 150 #80-90', 'pass12345', 2, 1),
(31, 'Luis Fonsi Ejemplo', '3188952220', 'Luisfonsi@gmail.com', 'Calleluisfonsi123', '$2y$10$hYSD4Q2MsJHIk', 2, 1),
(32, 'sssssssss', '1111111111', 'ssssss@gmail.com', 'sssssssssss', '$2y$10$csmj5exwJcfp8', NULL, 1),
(33, 'Dilitandak', '1111111111', 'dilitandak@gmail.com', 'Dilandak1111', 'TnV0d1hSU0IzdGJ6S3Rv', NULL, 1),
(34, 'Probar', '1564645555', 'Probar@gmail.com', 'Casdasd', 'V3lGSEF1UWJEMEMwUEh4', NULL, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carrito`
--
ALTER TABLE `carrito`
  ADD PRIMARY KEY (`ID_carrito`);

--
-- Indices de la tabla `carrito_producto`
--
ALTER TABLE `carrito_producto`
  ADD PRIMARY KEY (`ID_carrito`,`ID_producto`),
  ADD KEY `ID_producto` (`ID_producto`);

--
-- Indices de la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  ADD PRIMARY KEY (`ID_factura`,`ID_producto`),
  ADD KEY `ID_producto` (`ID_producto`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`ID_factura`),
  ADD KEY `ID_usuario` (`ID_usuario`),
  ADD KEY `ID_metodo` (`ID_metodo`);

--
-- Indices de la tabla `metodo_pago`
--
ALTER TABLE `metodo_pago`
  ADD PRIMARY KEY (`ID_metodo`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`ID_producto`);

--
-- Indices de la tabla `resena`
--
ALTER TABLE `resena`
  ADD PRIMARY KEY (`ID_resena`),
  ADD KEY `ID_producto` (`ID_producto`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`ID_rol`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`ID_usuario`),
  ADD KEY `ID_rol` (`ID_rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carrito`
--
ALTER TABLE `carrito`
  MODIFY `ID_carrito` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `ID_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `metodo_pago`
--
ALTER TABLE `metodo_pago`
  MODIFY `ID_metodo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `ID_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `resena`
--
ALTER TABLE `resena`
  MODIFY `ID_resena` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `ID_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `ID_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carrito_producto`
--
ALTER TABLE `carrito_producto`
  ADD CONSTRAINT `carrito_producto_ibfk_1` FOREIGN KEY (`ID_carrito`) REFERENCES `carrito` (`ID_carrito`),
  ADD CONSTRAINT `carrito_producto_ibfk_2` FOREIGN KEY (`ID_producto`) REFERENCES `producto` (`ID_producto`);

--
-- Filtros para la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  ADD CONSTRAINT `detalle_factura_ibfk_1` FOREIGN KEY (`ID_factura`) REFERENCES `factura` (`ID_factura`),
  ADD CONSTRAINT `detalle_factura_ibfk_2` FOREIGN KEY (`ID_producto`) REFERENCES `producto` (`ID_producto`);

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`ID_usuario`) REFERENCES `usuarios` (`ID_usuario`),
  ADD CONSTRAINT `factura_ibfk_2` FOREIGN KEY (`ID_metodo`) REFERENCES `metodo_pago` (`ID_metodo`);

--
-- Filtros para la tabla `resena`
--
ALTER TABLE `resena`
  ADD CONSTRAINT `resena_ibfk_1` FOREIGN KEY (`ID_producto`) REFERENCES `producto` (`ID_producto`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`ID_rol`) REFERENCES `rol` (`ID_rol`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
