<?php
// Configuración de la conexión
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "stay_in_style";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$nombre = $conn->real_escape_string($_POST['nombre']);
$email = $conn->real_escape_string($_POST['email']);
$password = $_POST['password'];  // No se hace escape aquí ya que se encriptará
$direccion = $conn->real_escape_string($_POST['direccion']);
$num_cel = $conn->real_escape_string($_POST['num_cel']);

// Clave secreta para la encriptación y método
$encryption_key = 'clave_secreta';  // Debe ser mantenida en un lugar seguro
$cipher_method = 'aes-256-cbc';  // Algoritmo de encriptación

// Generar un IV (Initialization Vector) para la encriptación
$iv_length = openssl_cipher_iv_length($cipher_method);
$iv = openssl_random_pseudo_bytes($iv_length);

// Encriptar la contraseña
$encrypted_password = openssl_encrypt($password, $cipher_method, $encryption_key, 0, $iv);
$encrypted_password = base64_encode($encrypted_password . '::' . base64_encode($iv));  // Almacenar el IV junto con la contraseña

// Preparar la consulta SQL
$sql = "INSERT INTO usuarios (nombre, email, password, direccion, num_cel) VALUES (?, ?, ?, ?, ?)";

// Preparar la sentencia
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error preparando la consulta: " . $conn->error);
}

// Vincular parámetros
$stmt->bind_param("sssss", $nombre, $email, $encrypted_password, $direccion, $num_cel);

// Ejecutar la consulta y verificar si se insertó correctamente
if ($stmt->execute()) {
    echo "Registro guardado con éxito";
} else {
    echo "Error: " . $stmt->error;
}

// Cerrar la conexión
$stmt->close();
$conn->close();
?>
