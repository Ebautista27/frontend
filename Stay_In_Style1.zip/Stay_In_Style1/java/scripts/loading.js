window.addEventListener('load', function() {
    const spinner = document.getElementById('spinner');
    spinner.classList.add('hidden');
});